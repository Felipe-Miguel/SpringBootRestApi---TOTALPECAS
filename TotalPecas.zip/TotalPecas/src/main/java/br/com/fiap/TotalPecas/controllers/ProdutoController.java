package br.com.fiap.TotalPecas.controllers;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.TotalPecas.models.Produto;

@RestController
public class ProdutoController {  
    
    @GetMapping("/api/produtos")
    public Produto show(){
        Produto produto = new Produto(new BigDecimal(100), "teste de produto", new ArrayList<Integer>() {
            {
                add(2012);
                add(2013);
            }
        });
        return produto;
    }
    

}
