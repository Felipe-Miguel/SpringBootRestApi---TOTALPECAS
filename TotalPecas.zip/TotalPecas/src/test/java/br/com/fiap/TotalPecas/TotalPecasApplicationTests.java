package br.com.fiap.TotalPecas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TotalPecasApplicationTests {

	@Test
	void contextLoads() {
	}

}
